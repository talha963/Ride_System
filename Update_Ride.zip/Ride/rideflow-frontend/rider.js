// ============================================
// rider.js — Rider Dashboard Logic
// ============================================

// ---- Route Guard: Only Riders can access this page ----
if (!guardRoute('Rider')) {
    // guardRoute will redirect if unauthorized
}

const user = getUser();

// ---- Set User Info in Header ----
const greetingEl = document.getElementById('greeting');
if (greetingEl) greetingEl.textContent = `Good ${getTimeGreeting()}, ${user.FullName.split(' ')[0]}`;

const dateDisplayEl = document.getElementById('dateDisplay');
if (dateDisplayEl) dateDisplayEl.textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

const userAvatarEl = document.getElementById('userAvatar');
if (userAvatarEl) userAvatarEl.textContent = user.FullName.charAt(0).toUpperCase();

// Wallet balance from user object
const walletBalance = user.WalletBalance || 0;
document.getElementById('walletDisplay').textContent = `Rs. ${walletBalance}`;
document.getElementById('walletAmount').textContent = `Rs. ${walletBalance}`;

function getTimeGreeting() {
    const h = new Date().getHours();
    if (h < 12) return 'morning';
    if (h < 17) return 'afternoon';
    return 'evening';
}

// ---- Sidebar Navigation (SPA-style view switching) ----
const navItems = document.querySelectorAll('.nav-item[data-view]');
const viewSections = document.querySelectorAll('.view-section');

navItems.forEach(item => {
    item.addEventListener('click', function () {
        const targetView = this.dataset.view;

        // Update active nav
        navItems.forEach(n => n.classList.remove('active'));
        this.classList.add('active');

        // Show the target view, hide others
        viewSections.forEach(section => {
            section.classList.remove('active');
            if (section.id === `view-${targetView}`) {
                section.classList.add('active');
            }
        });
    });
});

// ---- Logout ----
document.getElementById('logoutBtn').addEventListener('click', logout);

// ============================================
// FETCH RIDES FROM DATABASE
// ============================================

let myRides = [];
let pollingInterval = null;
let skippedRatings = new Set(JSON.parse(localStorage.getItem('skippedRatings') || '[]'));

async function fetchMyRides() {
    try {
        const response = await authFetch('/rides/my-rides');
        if (response && response.ok) {
            myRides = await response.json();
            renderRecentRides();
            renderAllRides();
            updateStats();
            
            // Check if there are any completed rides that need rating
            const unratedRide = myRides.find(r => r.RideStatus === 'Completed' && r.HasRated === 0 && !skippedRatings.has(r.RideID));
            if (unratedRide && !document.getElementById('ratingModal').dataset.activeRideId) {
                showRatingModal(unratedRide);
            }
        } else {
            myRides = [];
        }
        
        // Also refresh wallet balance and transactions to keep them up to date
        await fetchWalletBalance();
        await fetchTransactions();
    } catch (error) {
        console.error('Error fetching rides:', error);
        myRides = [];
    }
}

// ---- Populate Recent Rides Table (Dashboard) ----
function renderRecentRides() {
    const tbody = document.getElementById('recentRidesTable');
    if (myRides.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--text-muted); padding:24px;">No rides yet. Book your first ride!</td></tr>';
        return;
    }
    tbody.innerHTML = myRides.slice(0, 5).map(ride => {
        let badgeClass = 'badge-success';
        if (ride.RideStatus === 'Cancelled') badgeClass = 'badge-error';
        if (ride.RideStatus === 'Requested' || ride.RideStatus === 'Accepted') badgeClass = 'badge-warning';
        return `
        <tr>
            <td>${ride.PickupAddress}</td>
            <td>${ride.PickupAddress} → ${ride.DropoffAddress}</td>
            <td>Rs. ${ride.Fare}</td>
            <td><span class="badge ${badgeClass}">${ride.RideStatus}</span></td>
        </tr>
    `;
    }).join('');
}

// ---- Populate All Rides Table ----
function renderAllRides() {
    const tbody = document.getElementById('allRidesTable');
    if (myRides.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted); padding:24px;">No rides found.</td></tr>';
        return;
    }
    tbody.innerHTML = myRides.map(ride => {
        let badgeClass = 'badge-success';
        if (ride.RideStatus === 'Cancelled') badgeClass = 'badge-error';
        if (ride.RideStatus === 'Requested' || ride.RideStatus === 'Accepted') badgeClass = 'badge-warning';
        
        let vehicleInfo = '-';
        if (ride.VehicleMake && ride.VehicleModel) {
            vehicleInfo = `${ride.VehicleMake} ${ride.VehicleModel}<br><span style="font-size:12px; color:var(--text-muted);">${ride.VehiclePlate}</span>`;
        }
        
        return `
        <tr>
            <td>${ride.RideID}</td>
            <td>${ride.PickupAddress} → ${ride.DropoffAddress}</td>
            <td>${vehicleInfo}</td>
            <td>Rs. ${ride.Fare}</td>
            <td><span class="badge ${badgeClass}">${ride.RideStatus}</span></td>
            <td>${ride.DriverName || 'Waiting...'}</td>
        </tr>
    `;
    }).join('');
}

// ---- Update Stats ----
function updateStats() {
    const completedRides = myRides.filter(r => r.RideStatus === 'Completed').length;
    document.getElementById('totalRides').textContent = myRides.length || 0;
}

// Load rides on page load and start polling
fetchMyRides();
pollingInterval = setInterval(fetchMyRides, 5000);

// ============================================
// GOOGLE MAPS & DYNAMIC PRICING (Booking)
// ============================================
let map, directionsService, directionsRenderer;
let pickupAutocomplete, dropoffAutocomplete;

// Base fares and per km rates
const PRICING_RATES = {
    Economy: { base: 100, perKm: 20 },
    Comfort: { base: 150, perKm: 30 },
    Premium: { base: 250, perKm: 50 }
};

function initMap() {
    const mapContainer = document.getElementById('map');
    
    // Check if google maps API is loaded
    if (typeof google === 'undefined' || !google.maps) {
        console.warn('Google Maps API not loaded. Check API key.');
        return;
    }

    // Initialize Map with custom dark styling
    map = new google.maps.Map(mapContainer, {
        center: { lat: 33.6844, lng: 73.0479 }, // Default to Islamabad
        zoom: 12,
        mapTypeId: 'roadmap',
        disableDefaultUI: true,
        zoomControl: true,
        styles: [
            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
            { featureType: "administrative.locality", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
            { featureType: "road", elementType: "geometry", stylers: [{ color: "#38414e" }] },
            { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#212a37" }] },
            { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#9ca5b3" }] },
            { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#746855" }] },
            { featureType: "road.highway", elementType: "geometry.stroke", stylers: [{ color: "#1f2835" }] },
            { featureType: "road.highway", elementType: "labels.text.fill", stylers: [{ color: "#f3d19c" }] },
            { featureType: "transit", elementType: "geometry", stylers: [{ color: "#2f3948" }] },
            { featureType: "water", elementType: "geometry", stylers: [{ color: "#17263c" }] },
            { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#515c6d" }] },
            { featureType: "water", elementType: "labels.text.stroke", stylers: [{ color: "#17263c" }] }
        ],
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({
        map: map,
        polylineOptions: {
            strokeColor: '#00f0ff',
            strokeOpacity: 0.8,
            strokeWeight: 5
        }
    });

    const pickupInput = document.getElementById('pickup');
    const dropoffInput = document.getElementById('dropoff');

    pickupAutocomplete = new google.maps.places.Autocomplete(pickupInput);
    dropoffAutocomplete = new google.maps.places.Autocomplete(dropoffInput);

    pickupAutocomplete.addListener('place_changed', calculateRouteAndFare);
    dropoffAutocomplete.addListener('place_changed', calculateRouteAndFare);
    
    pickupInput.addEventListener('blur', calculateRouteAndFare);
    dropoffInput.addEventListener('blur', calculateRouteAndFare);
}

function calculateRouteAndFare() {
    const pickup = document.getElementById('pickup').value;
    const dropoff = document.getElementById('dropoff').value;

    if (!pickup || !dropoff) return;

    // Show map if hidden
    const mapContainer = document.getElementById('map');
    if (mapContainer.style.display === 'none') {
        mapContainer.style.display = 'block';
        if (map) google.maps.event.trigger(map, 'resize');
    }

    if (!directionsService) return;

    const request = {
        origin: pickup,
        destination: dropoff,
        travelMode: 'DRIVING'
    };

    directionsService.route(request, function(result, status) {
        if (status === 'OK') {
            directionsRenderer.setDirections(result);
            
            const route = result.routes[0].legs[0];
            const distanceText = route.distance.text;
            const distanceValue = route.distance.value; // in meters
            const distanceKm = distanceValue / 1000;
            
            // Show distance info
            const distanceInfoBox = document.getElementById('distance-info');
            distanceInfoBox.classList.remove('hidden');
            distanceInfoBox.innerHTML = `<strong>Distance:</strong> ${distanceText} | <strong>Est. Time:</strong> ${route.duration.text}`;
            
            // Calculate and update prices
            updateFares(distanceKm);
            
            // Re-fetch the verified address strings from the result
            document.getElementById('pickup').value = route.start_address;
            document.getElementById('dropoff').value = route.end_address;
        } else {
            console.error('Directions request failed due to ' + status);
        }
    });
}

function updateFares(distanceKm) {
    const vehicleOptions = document.querySelectorAll('.vehicle-card');
    vehicleOptions.forEach(option => {
        const type = option.dataset.type;
        const rate = PRICING_RATES[type];
        if (rate) {
            const calculatedFare = Math.round(rate.base + (distanceKm * rate.perKm));
            option.dataset.price = calculatedFare;
            
            const priceEl = option.querySelector('.vehicle-price');
            if (priceEl) priceEl.textContent = `~Rs. ${calculatedFare}`;
            
            // If this option is currently selected, update the big fare display
            if (option.classList.contains('active')) {
                const fareEstimateEl = document.getElementById('fareEstimate');
                if (fareEstimateEl) fareEstimateEl.textContent = `Rs. ${calculatedFare}`;
            }
        }
    });
}

// Initialize map on window load
window.addEventListener('load', initMap);

// Re-trigger map resize when navigating to "Book a Ride"
navItems.forEach(item => {
    item.addEventListener('click', function () {
        if (this.dataset.view === 'book-ride' && map) {
            setTimeout(() => {
                google.maps.event.trigger(map, 'resize');
            }, 100);
        }
    });
});

// ============================================
// BOOK A RIDE — Real API Call
// ============================================

// Vehicle type selection
const vehicleOptions = document.querySelectorAll('.vehicle-card');
vehicleOptions.forEach(option => {
    option.addEventListener('click', function () {
        vehicleOptions.forEach(o => o.classList.remove('active'));
        this.classList.add('active');
        document.getElementById('fareEstimate').textContent = `Rs. ${this.dataset.price}`;
    });
});

// Request Ride Button — NOW calls the real API
document.getElementById('requestRideBtn').addEventListener('click', async function () {
    const pickup = document.getElementById('pickup').value;
    const dropoff = document.getElementById('dropoff').value;
    const msgBox = document.getElementById('bookingMessage');

    if (!pickup || !dropoff) {
        msgBox.textContent = 'Please enter both pickup and drop-off locations.';
        msgBox.className = 'message-box error';
        return;
    }

    const selectedVehicle = document.querySelector('.vehicle-card.active');
    const vehicleType = selectedVehicle.dataset.type;
    const fare = selectedVehicle.dataset.price;

    // Disable button while loading
    this.disabled = true;
    this.textContent = '⏳ Booking...';

    try {
        const response = await authFetch('/rides', {
            method: 'POST',
            body: JSON.stringify({
                PickupAddress: pickup,
                DropoffAddress: dropoff,
                VehicleType: vehicleType,
                Fare: fare
            })
        });

        const data = await response.json();

        if (response.ok) {
            msgBox.textContent = `✅ ${data.message} Ride #${data.RideID} — Looking for a ${vehicleType} driver near ${pickup}...`;
            msgBox.className = 'message-box success';

            // Clear form
            document.getElementById('pickup').value = '';
            document.getElementById('dropoff').value = '';

            // Refresh rides list
            await fetchMyRides();
        } else {
            msgBox.textContent = data.error || 'Failed to book ride.';
            msgBox.className = 'message-box error';
        }
    } catch (error) {
        console.error('Book ride error:', error);
        msgBox.textContent = 'Network error. Please try again.';
        msgBox.className = 'message-box error';
    }

    // Re-enable button
    this.disabled = false;
    this.textContent = '🚗 Request Ride';
});

// ============================================
// WALLET — Real API Calls
// ============================================

// Fetch wallet balance from DB on page load
async function fetchWalletBalance() {
    try {
        const response = await authFetch('/wallet/balance');
        if (response && response.ok) {
            const data = await response.json();
            const balance = parseFloat(data.WalletBalance) || 0;
            document.getElementById('walletDisplay').textContent = `Rs. ${balance.toLocaleString()}`;
            document.getElementById('walletAmount').textContent = `Rs. ${balance.toLocaleString()}`;

            // Update localStorage so it persists
            const storedUser = getUser();
            storedUser.WalletBalance = balance;
            localStorage.setItem('user', JSON.stringify(storedUser));
        }
    } catch (error) {
        console.error('Error fetching wallet balance:', error);
    }
}
fetchWalletBalance();

// Fetch transaction history from DB
async function fetchTransactions() {
    try {
        const response = await authFetch('/wallet/transactions');
        if (response && response.ok) {
            const transactions = await response.json();
            renderTransactions(transactions);
        }
    } catch (error) {
        console.error('Error fetching transactions:', error);
    }
}
fetchTransactions();

function renderTransactions(transactions) {
    const tbody = document.getElementById('transactionTable');
    if (!transactions || transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--text-muted); padding:24px;">No transactions yet.</td></tr>';
        return;
    }
    tbody.innerHTML = transactions.map(t => {
        const date = new Date(t.TransactionDate).toLocaleDateString('en-US');
        const type = t.RideID ? 'Ride Payment' : 'Top Up';
        const amountPrefix = t.RideID ? '-' : '+';
        const color = t.RideID ? 'var(--error)' : 'var(--success)';
        return `
        <tr>
            <td>${date}</td>
            <td>${type}</td>
            <td style="color: ${color}; font-weight:600;">${amountPrefix}Rs. ${parseFloat(t.Amount).toLocaleString()}</td>
            <td><span class="badge badge-success">${t.PaymentStatus}</span></td>
        </tr>
    `;
    }).join('');
}

// Top Up Button — Real API Call
document.getElementById('topupBtn').addEventListener('click', async function () {
    const amount = document.getElementById('topupAmount').value;
    const msgBox = document.getElementById('topupMessage');

    if (!amount || amount < 100) {
        msgBox.textContent = 'Minimum top-up amount is Rs. 100';
        msgBox.className = 'message-box error';
        return;
    }

    this.disabled = true;
    this.textContent = '⏳ Processing...';

    try {
        const response = await authFetch('/wallet/topup', {
            method: 'POST',
            body: JSON.stringify({ Amount: parseFloat(amount) })
        });

        const data = await response.json();

        if (response.ok) {
            msgBox.textContent = `✅ ${data.message}`;
            msgBox.className = 'message-box success';
            document.getElementById('topupAmount').value = '';

            // Update balance displays
            const balance = parseFloat(data.WalletBalance) || 0;
            document.getElementById('walletDisplay').textContent = `Rs. ${balance.toLocaleString()}`;
            document.getElementById('walletAmount').textContent = `Rs. ${balance.toLocaleString()}`;

            // Update localStorage
            const storedUser = getUser();
            storedUser.WalletBalance = balance;
            localStorage.setItem('user', JSON.stringify(storedUser));

            // Refresh transactions
            await fetchTransactions();
        } else {
            msgBox.textContent = data.error || 'Failed to add funds.';
            msgBox.className = 'message-box error';
        }
    } catch (error) {
        console.error('Top up error:', error);
        msgBox.textContent = 'Network error. Please try again.';
        msgBox.className = 'message-box error';
    }

    this.disabled = false;
    this.textContent = '💰 Add Funds';
});

// ============================================
// PROFILE
// ============================================

// Pre-fill profile form with user data
// TODO: Replace with API call → GET /api/users/<UserID>
document.getElementById('profileName').value = user.FullName || '';
document.getElementById('profileEmail').value = user.Email || '';
document.getElementById('profilePhone').value = user.PhoneNumber || '';

// Save Profile
// TODO: Replace with API call → PUT /api/users/<UserID>
document.getElementById('saveProfileBtn').addEventListener('click', function () {
    const name = document.getElementById('profileName').value;
    const phone = document.getElementById('profilePhone').value;
    const msgBox = document.getElementById('profileMessage');

    console.log('Profile Update:', { name, phone, userId: user.UserID });
    msgBox.textContent = 'Profile updated successfully!';
    msgBox.className = 'message-box success';
});

// ============================================
// RATING SYSTEM
// ============================================

function showRatingModal(ride) {
    const modal = document.getElementById('ratingModal');
    modal.style.display = 'flex';
    modal.dataset.activeRideId = ride.RideID;
    
    document.getElementById('ratingDriverName').textContent = `How was your ride with ${ride.DriverName || 'your driver'}?`;
    document.getElementById('ratingRideId').value = ride.RideID;
    
    // Reset stars
    document.getElementById('ratingScore').value = 0;
    document.getElementById('submitRatingBtn').disabled = true;
    document.querySelectorAll('#starContainer span').forEach(s => s.style.color = 'var(--text-muted)');
    
    document.getElementById('ratingMessage').className = 'message-box hidden';
}

function hideRatingModal() {
    const modal = document.getElementById('ratingModal');
    modal.style.display = 'none';
    delete modal.dataset.activeRideId;
}

// Star Click Handler
document.querySelectorAll('#starContainer span').forEach(star => {
    star.addEventListener('click', function() {
        const val = parseInt(this.dataset.val);
        document.getElementById('ratingScore').value = val;
        document.getElementById('submitRatingBtn').disabled = false;
        
        // Highlight stars
        document.querySelectorAll('#starContainer span').forEach(s => {
            if (parseInt(s.dataset.val) <= val) {
                s.style.color = 'var(--warning)';
            } else {
                s.style.color = 'var(--text-muted)';
            }
        });
    });
});

// Skip Rating
document.getElementById('skipRatingBtn').addEventListener('click', function() {
    const rideId = document.getElementById('ratingRideId').value;
    if (rideId) {
        skippedRatings.add(parseInt(rideId));
        localStorage.setItem('skippedRatings', JSON.stringify([...skippedRatings]));
    }
    hideRatingModal();
});

// Submit Rating
document.getElementById('submitRatingBtn').addEventListener('click', async function() {
    const rideId = document.getElementById('ratingRideId').value;
    const score = document.getElementById('ratingScore').value;
    const msgBox = document.getElementById('ratingMessage');
    
    this.disabled = true;
    this.textContent = 'Submitting...';
    
    try {
        const response = await authFetch(`/rides/${rideId}/rate`, {
            method: 'POST',
            body: JSON.stringify({ Score: parseInt(score) })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            msgBox.textContent = 'Thanks for your feedback!';
            msgBox.className = 'message-box success';
            setTimeout(() => {
                hideRatingModal();
                fetchMyRides();
            }, 1500);
        } else {
            msgBox.textContent = data.error || 'Failed to submit rating.';
            msgBox.className = 'message-box error';
            this.textContent = 'Submit Rating';
            this.disabled = false;
        }
    } catch (error) {
        msgBox.textContent = 'Network error.';
        msgBox.className = 'message-box error';
        this.textContent = 'Submit Rating';
        this.disabled = false;
    }
});
