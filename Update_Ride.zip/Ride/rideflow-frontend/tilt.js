// Interactive 3D Tilt Effect
document.addEventListener("DOMContentLoaded", () => {
    function initTilt() {
        const tiltCards = document.querySelectorAll('.tilt-card');
        
        tiltCards.forEach(card => {
            // Add listeners directly without replacing the node
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left; // x position within the element.
                const y = e.clientY - rect.top;  // y position within the element.
                
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                
                const tiltX = ((y - centerY) / centerY) * -10; // Max tilt 10deg
                const tiltY = ((x - centerX) / centerX) * 10;
                
                card.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(1.02, 1.02, 1.02)`;
                
                // dynamic glare
                const glareX = (x / rect.width) * 100;
                const glareY = (y / rect.height) * 100;
                card.style.background = `
                    radial-gradient(
                        circle at ${glareX}% ${glareY}%, 
                        rgba(255,255,255,0.1) 0%, 
                        rgba(255,255,255,0) 60%
                    ),
                    var(--bg-card)
                `;
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
                card.style.background = `var(--bg-card)`;
            });
        });
    }

    // Initialize immediately
    initTilt();

    // Export to global scope so it can be re-initialized when data is fetched dynamically
    window.initTilt = initTilt;
});
