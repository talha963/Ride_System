// ============================================
// app.js — Login Page Logic
// Connects to: POST /api/auth/login
// ============================================

const loginForm = document.getElementById('loginForm');
const messageBox = document.getElementById('messageBox');
const submitBtn = document.getElementById('submitBtn');
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('password');

// If already logged in, redirect to dashboard
if (isLoggedIn()) {
    const user = getUser();
    if (user) redirectToDashboard(user.Role);
}

// Password visibility toggle
togglePassword.addEventListener('click', function () {
    const type = passwordInput.type === 'password' ? 'text' : 'password';
    passwordInput.type = type;
    this.textContent = type === 'password' ? '👁️' : '🙈';
});

// Handle login form submission
loginForm.addEventListener('submit', async function (event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = passwordInput.value;

    // Reset message box and show loading state
    messageBox.className = 'message-box hidden';
    submitBtn.textContent = 'Signing in...';
    submitBtn.disabled = true;

    try {
        // Send login request to the backend
        const response = await fetch('http://localhost:5000/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Email: email, Password: password })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Login failed');
        }

        // ---- SUCCESS ----
        // Save the JWT token and user data in localStorage
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));

        // Show success message
        messageBox.textContent = `Welcome back, ${data.user.FullName}!`;
        messageBox.className = 'message-box success';

        // Redirect based on role after a short delay
        setTimeout(() => {
            redirectToDashboard(data.user.Role);
        }, 1000);

    } catch (error) {
        // Show error with shake animation
        messageBox.textContent = error.message;
        messageBox.className = 'message-box error';

        const card = document.querySelector('.auth-card');
        card.classList.add('shake');
        setTimeout(() => card.classList.remove('shake'), 400);

    } finally {
        submitBtn.textContent = 'Sign In';
        submitBtn.disabled = false;
    }
});