// ============================================
// register.js — Registration Page Logic
// Connects to: POST /api/auth/register
// ============================================

const registerForm = document.getElementById('registerForm');
const regMessageBox = document.getElementById('regMessageBox');
const regSubmitBtn = document.getElementById('regSubmitBtn');
const regPasswordInput = document.getElementById('regPassword');
const toggleRegPassword = document.getElementById('toggleRegPassword');
const strengthFill = document.getElementById('strengthFill');
const strengthText = document.getElementById('strengthText');
const roleOptions = document.querySelectorAll('.role-option');
const regRoleInput = document.getElementById('regRole');

// ---- Password Toggle ----
toggleRegPassword.addEventListener('click', function () {
    const type = regPasswordInput.type === 'password' ? 'text' : 'password';
    regPasswordInput.type = type;
    this.textContent = type === 'password' ? '👁️' : '🙈';
});

// ---- Password Strength Meter ----
regPasswordInput.addEventListener('input', function () {
    const val = this.value;
    let score = 0;
    if (val.length >= 6) score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;

    const levels = [
        { width: '0%', color: 'transparent', text: '' },
        { width: '20%', color: '#ef4444', text: 'Very Weak' },
        { width: '40%', color: '#f59e0b', text: 'Weak' },
        { width: '60%', color: '#eab308', text: 'Fair' },
        { width: '80%', color: '#22c55e', text: 'Strong' },
        { width: '100%', color: '#16a34a', text: 'Very Strong' }
    ];

    const level = levels[score];
    strengthFill.style.width = level.width;
    strengthFill.style.background = level.color;
    strengthText.textContent = level.text;
    strengthText.style.color = level.color;
});

const driverExtraFields = document.getElementById('driverExtraFields');

// ---- Role Toggle (Rider / Driver) ----
roleOptions.forEach(option => {
    option.addEventListener('click', function () {
        roleOptions.forEach(o => o.classList.remove('active'));
        this.classList.add('active');
        const selectedRole = this.dataset.role;
        regRoleInput.value = selectedRole;
        
        // Show extra fields if Driver is selected
        if (selectedRole === 'Driver') {
            driverExtraFields.style.display = 'block';
            // Add required attribute to driver fields
            document.getElementById('regCNIC').required = true;
            document.getElementById('regLicense').required = true;
            document.getElementById('regVehicleMake').required = true;
            document.getElementById('regVehicleModel').required = true;
            document.getElementById('regVehicleYear').required = true;
            document.getElementById('regVehicleColor').required = true;
            document.getElementById('regVehiclePlate').required = true;
        } else {
            driverExtraFields.style.display = 'none';
            // Remove required attribute
            document.getElementById('regCNIC').required = false;
            document.getElementById('regLicense').required = false;
            document.getElementById('regVehicleMake').required = false;
            document.getElementById('regVehicleModel').required = false;
            document.getElementById('regVehicleYear').required = false;
            document.getElementById('regVehicleColor').required = false;
            document.getElementById('regVehiclePlate').required = false;
        }
    });
});

// ---- Handle Registration ----
registerForm.addEventListener('submit', async function (event) {
    event.preventDefault();

    const fullName = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const phone = document.getElementById('regPhone').value;
    const password = regPasswordInput.value;
    const role = regRoleInput.value;

    let driverData = {};
    if (role === 'Driver') {
        driverData = {
            CNIC: document.getElementById('regCNIC').value,
            LicenseNumber: document.getElementById('regLicense').value,
            VehicleMake: document.getElementById('regVehicleMake').value,
            VehicleModel: document.getElementById('regVehicleModel').value,
            VehicleYear: parseInt(document.getElementById('regVehicleYear').value),
            VehicleColor: document.getElementById('regVehicleColor').value,
            VehiclePlate: document.getElementById('regVehiclePlate').value,
            VehicleType: document.getElementById('regVehicleType').value
        };
    }

    regMessageBox.className = 'message-box hidden';
    regSubmitBtn.textContent = 'Creating account...';
    regSubmitBtn.disabled = true;

    try {
        // Send registration data to the backend
        const response = await fetch('http://localhost:5000/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                FullName: fullName,
                Email: email,
                PhoneNumber: phone,
                Password: password,
                Role: role,
                ...driverData
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Registration failed');
        }

        // Show success and redirect to login
        regMessageBox.textContent = 'Account created successfully! Redirecting to login...';
        regMessageBox.className = 'message-box success';

        setTimeout(() => {
            window.location.href = 'index.html';
        }, 2000);

    } catch (error) {
        regMessageBox.textContent = error.message;
        regMessageBox.className = 'message-box error';

        const card = document.querySelector('.auth-card');
        card.classList.add('shake');
        setTimeout(() => card.classList.remove('shake'), 400);

    } finally {
        regSubmitBtn.textContent = 'Create Account';
        regSubmitBtn.disabled = false;
    }
});