// ============================================
// admin.js — Admin Dashboard Logic
// ============================================

// ---- Route Guard: Only Admins can access ----
if (!guardRoute('Admin')) { /* redirects automatically */ }

const user = getUser();

// ---- Header Info ----
document.getElementById('dateDisplay').textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
document.getElementById('userAvatar').textContent = user.FullName.charAt(0).toUpperCase();

// ---- Sidebar Navigation ----
const navItems = document.querySelectorAll('.nav-item[data-view]');
const viewSections = document.querySelectorAll('.view-section');

navItems.forEach(item => {
    item.addEventListener('click', function () {
        const targetView = this.dataset.view;
        navItems.forEach(n => n.classList.remove('active'));
        this.classList.add('active');
        viewSections.forEach(section => {
            section.classList.remove('active');
            if (section.id === `view-${targetView}`) section.classList.add('active');
        });
    });
});

// ---- Logout ----
document.getElementById('logoutBtn').addEventListener('click', logout);

// ============================================
// FETCH AND RENDER REAL DATA
// ============================================

let allUsers = [];
let allRides = [];

// Fetch Overview Data
async function fetchOverview() {
    try {
        const res = await authFetch('/admin/overview');
        if (res.ok) {
            const data = await res.json();
            document.getElementById('totalUsers').textContent = data.totalUsers;
            document.getElementById('activeRides').textContent = data.activeRides;
            document.getElementById('totalRevenue').textContent = `Rs. ${parseFloat(data.totalRevenue).toLocaleString()}`;
            document.getElementById('suspendedCount').textContent = data.suspendedCount;

            renderRecentUsers(data.recentUsers);
            renderRecentRidesOverview(data.recentRides);
        }
    } catch (e) {
        console.error('Failed to fetch overview data');
    }
}

// Fetch Users Data
async function fetchUsers() {
    try {
        const res = await authFetch('/admin/users');
        if (res.ok) {
            allUsers = await res.json();
            renderUsersTable();
        }
    } catch (e) {
        console.error('Failed to fetch users');
    }
}

// Fetch Rides Data
async function fetchRides() {
    try {
        const res = await authFetch('/admin/rides');
        if (res.ok) {
            allRides = await res.json();
            renderAllRides();
        }
    } catch (e) {
        console.error('Failed to fetch rides');
    }
}

// ============================================
// RENDER FUNCTIONS
// ============================================

function renderRecentUsers(users) {
    const tbody = document.getElementById('recentUsersTable');
    if(!users || users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;">No recent users</td></tr>';
        return;
    }
    tbody.innerHTML = users.map(u => `
        <tr>
            <td>${u.FullName}</td>
            <td><span class="badge ${u.Role === 'Rider' ? 'badge-info' : 'badge-warning'}">${u.Role}</span></td>
            <td>${new Date(u.RegistrationDate).toLocaleDateString()}</td>
        </tr>
    `).join('');
}

function renderRecentRidesOverview(rides) {
    const tbody = document.getElementById('recentRidesOverview');
    if(!rides || rides.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;">No recent rides</td></tr>';
        return;
    }
    tbody.innerHTML = rides.map(r => {
        let badgeClass = 'badge-success';
        if (r.RideStatus === 'Cancelled') badgeClass = 'badge-error';
        if (r.RideStatus === 'In Progress' || r.RideStatus === 'Accepted') badgeClass = 'badge-warning';
        return `
            <tr>
                <td>${r.PickupAddress} → ${r.DropoffAddress}</td>
                <td>Rs. ${r.Fare}</td>
                <td><span class="badge ${badgeClass}">${r.RideStatus}</span></td>
            </tr>
        `;
    }).join('');
}

function renderUsersTable(filter = '') {
    const tbody = document.getElementById('usersTable');
    const filtered = allUsers.filter(u =>
        u.FullName.toLowerCase().includes(filter.toLowerCase()) ||
        u.Email.toLowerCase().includes(filter.toLowerCase()) ||
        u.Role.toLowerCase().includes(filter.toLowerCase())
    );

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No users found</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(u => {
        let statusBadge = 'badge-success';
        if (u.AccountStatus === 'Suspended') statusBadge = 'badge-warning';
        if (u.AccountStatus === 'Banned') statusBadge = 'badge-error';

        // Cannot suspend/activate Admin
        let actionBtn = '-';
        if (u.Role !== 'Admin') {
            actionBtn = u.AccountStatus === 'Active'
                ? `<button class="btn btn-danger btn-sm" onclick="toggleUserStatus(${u.UserID}, 'Suspended')">Suspend</button>`
                : `<button class="btn btn-success btn-sm" onclick="toggleUserStatus(${u.UserID}, 'Active')">Activate</button>`;
        }

        return `
            <tr>
                <td>${u.UserID}</td>
                <td>${u.FullName}</td>
                <td>${u.Email}</td>
                <td><span class="badge ${u.Role === 'Rider' ? 'badge-info' : 'badge-warning'}">${u.Role}</span></td>
                <td><span class="badge ${statusBadge}">${u.AccountStatus}</span></td>
                <td>${actionBtn}</td>
            </tr>
        `;
    }).join('');
}

document.getElementById('userSearch').addEventListener('input', function () {
    renderUsersTable(this.value);
});

async function toggleUserStatus(id, newStatus) {
    try {
        const res = await authFetch(`/admin/users/${id}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status: newStatus })
        });
        if (res.ok) {
            // Re-fetch users to update UI
            fetchUsers();
        } else {
            alert('Failed to update status');
        }
    } catch (e) {
        console.error(e);
        alert('Network error');
    }
}

function renderAllRides(filter = '') {
    const tbody = document.getElementById('allRidesTable');
    const filtered = allRides.filter(r =>
        (r.RiderName && r.RiderName.toLowerCase().includes(filter.toLowerCase())) ||
        (r.DriverName && r.DriverName.toLowerCase().includes(filter.toLowerCase())) ||
        (r.PickupAddress && r.PickupAddress.toLowerCase().includes(filter.toLowerCase())) ||
        (r.DropoffAddress && r.DropoffAddress.toLowerCase().includes(filter.toLowerCase()))
    );

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No rides found</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(r => {
        let badgeClass = 'badge-success';
        if (r.RideStatus === 'Cancelled') badgeClass = 'badge-error';
        if (r.RideStatus === 'In Progress' || r.RideStatus === 'Accepted') badgeClass = 'badge-warning';
        return `
            <tr>
                <td>${r.RideID}</td>
                <td>${r.RiderName || '-'}</td>
                <td>${r.DriverName || '-'}</td>
                <td>${r.PickupAddress} → ${r.DropoffAddress}</td>
                <td>Rs. ${r.Fare}</td>
                <td><span class="badge ${badgeClass}">${r.RideStatus}</span></td>
            </tr>
        `;
    }).join('');
}

document.getElementById('rideSearch').addEventListener('input', function () {
    renderAllRides(this.value);
});

// Initialization
fetchOverview();
fetchUsers();
fetchRides();

// Update Data Periodically
setInterval(() => {
    fetchOverview();
    fetchUsers();
    fetchRides();
}, 10000);
