// ============================================
// driver.js — Driver Dashboard Logic
// ============================================

// ---- Route Guard: Only Drivers can access ----
if (!guardRoute('Driver')) { /* redirects automatically */ }

const user = getUser();

// ---- Header Info ----
const greetingEl = document.getElementById('greeting');
if (greetingEl) greetingEl.textContent = `Good ${getTimeGreeting()}, ${user.FullName.split(' ')[0]}`;

const dateDisplayEl = document.getElementById('dateDisplay');
if (dateDisplayEl) dateDisplayEl.textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

const userAvatarEl = document.getElementById('userAvatar');
if (userAvatarEl) userAvatarEl.textContent = user.FullName.charAt(0).toUpperCase();

function getTimeGreeting() {
    const h = new Date().getHours();
    if (h < 12) return 'morning';
    if (h < 17) return 'afternoon';
    return 'evening';
}

// ---- Sidebar Navigation ----
const navItems = document.querySelectorAll('.nav-item[data-view]');
const viewSections = document.querySelectorAll('.view-section');

navItems.forEach(item => {
    item.addEventListener('click', function () {
        const targetView = this.dataset.view;
        navItems.forEach(n => n.classList.remove('active'));
        this.classList.add('active');
        viewSections.forEach(section => {
            section.classList.remove('active');
            if (section.id === `view-${targetView}`) section.classList.add('active');
        });
    });
});

// ---- Logout ----
document.getElementById('logoutBtn').addEventListener('click', logout);

// ============================================
// MAP & ANIMATION LOGIC
// ============================================
let driverMap, directionsService, directionsRenderer;
let carMarker;
let routePath = [];
let animationInterval;
let activeRideId = null;
let activeRideVehicleType = 'Economy';

function initDriverMap() {
    const mapContainer = document.getElementById('driverMap');
    if (!mapContainer || typeof google === 'undefined' || !google.maps) return;

    driverMap = new google.maps.Map(mapContainer, {
        center: { lat: 33.6844, lng: 73.0479 },
        zoom: 13,
        disableDefaultUI: true,
        styles: [
            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
            { featureType: "road", elementType: "geometry", stylers: [{ color: "#38414e" }] },
            { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#212a37" }] },
            { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#9ca5b3" }] }
        ]
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({
        map: driverMap,
        suppressMarkers: true, // We will use custom marker for car
        polylineOptions: { strokeColor: '#00f0ff', strokeWeight: 5, strokeOpacity: 0.8 }
    });
}

function startRideAnimation(pickup, dropoff, rideId, vehicleType = 'Economy') {
    activeRideId = rideId;
    activeRideVehicleType = vehicleType;
    
    document.getElementById('activeRideSection').style.display = 'block';
    const incReqCard = document.getElementById('incomingRequestsCard');
    if (incReqCard) incReqCard.style.display = 'none';
    document.getElementById('completeRideBtn').style.display = 'none';
    document.getElementById('activeRideTitle').textContent = 'Driving to Destination...';
    
    if (!driverMap) initDriverMap();
    if (driverMap) google.maps.event.trigger(driverMap, 'resize');

    if (!directionsService) return;

    const request = { origin: pickup, destination: dropoff, travelMode: 'DRIVING' };

    directionsService.route(request, (result, status) => {
        if (status === 'OK') {
            directionsRenderer.setDirections(result);
            const route = result.routes[0].legs[0];
            
            const infoBox = document.getElementById('driverDistanceInfo');
            infoBox.classList.remove('hidden');
            infoBox.innerHTML = `<strong>Distance:</strong> ${route.distance.text} | <strong>Est. Time:</strong> ${route.duration.text}`;

            // Calculate duration (e.g. 14 mins = 840 seconds)
            // Make animation generic: For a realistic demo, let's animate at 10x real speed. 
            // So 14 mins (840s) will take 84 seconds. Minimum 5 seconds.
            const totalDurationSecs = route.duration.value;
            window.activeRideTotalMs = Math.max(5000, (totalDurationSecs * 1000) / 10); 

            routePath = result.routes[0].overview_path;
            
            let iconUrl = 'https://cdn-icons-png.flaticon.com/512/741/741407.png'; // car
            if (activeRideVehicleType.toLowerCase().includes('bike') || activeRideVehicleType.toLowerCase() === 'moto') {
                iconUrl = 'https://cdn-icons-png.flaticon.com/512/2972/2972185.png'; // bike
            }
            
            if (carMarker) carMarker.setMap(null);
            carMarker = new google.maps.Marker({
                position: routePath[0],
                map: driverMap,
                icon: {
                    url: iconUrl,
                    scaledSize: new google.maps.Size(40, 40)
                }
            });

            animateCar();
        }
    });
}

function animateCar() {
    if (animationInterval) clearInterval(animationInterval);

    const totalMs = window.activeRideTotalMs || 10000;
    const fps = 60;
    const intervalMs = 1000 / fps;
    const totalFrames = totalMs / intervalMs;
    
    // Calculate total proportional distance of the path
    let pathDistances = [];
    let totalDistance = 0;
    for (let i = 0; i < routePath.length - 1; i++) {
        const p1 = routePath[i];
        const p2 = routePath[i+1];
        const dLat = p2.lat() - p1.lat();
        const dLng = p2.lng() - p1.lng();
        const dist = Math.sqrt(dLat*dLat + dLng*dLng);
        pathDistances.push(dist);
        totalDistance += dist;
    }

    let currentFrame = 0;

    animationInterval = setInterval(() => {
        currentFrame++;
        let progress = currentFrame / totalFrames; // 0.0 to 1.0

        if (progress >= 1.0) {
            clearInterval(animationInterval);
            carMarker.setPosition(routePath[routePath.length - 1]);
            document.getElementById('completeRideBtn').style.display = 'inline-block';
            document.getElementById('activeRideTitle').textContent = 'Arrived at Destination';
            return;
        }

        // Find which segment we are currently in
        let targetDist = progress * totalDistance;
        let accumulatedDist = 0;
        let segmentIndex = 0;
        let segmentProgress = 0;

        for (let i = 0; i < pathDistances.length; i++) {
            if (accumulatedDist + pathDistances[i] >= targetDist) {
                segmentIndex = i;
                // Avoid division by zero
                segmentProgress = pathDistances[i] > 0 ? (targetDist - accumulatedDist) / pathDistances[i] : 0;
                break;
            }
            accumulatedDist += pathDistances[i];
        }

        // Handle edge case if float math exceeds array bounds
        if (segmentIndex >= routePath.length - 1) {
            segmentIndex = routePath.length - 2;
            segmentProgress = 1;
        }

        const p1 = routePath[segmentIndex];
        const p2 = routePath[segmentIndex + 1];

        // Linearly interpolate between the two segment points
        const currentLat = p1.lat() + (p2.lat() - p1.lat()) * segmentProgress;
        const currentLng = p1.lng() + (p2.lng() - p1.lng()) * segmentProgress;

        const newPos = new google.maps.LatLng(currentLat, currentLng);
        carMarker.setPosition(newPos);
        
        // Update map center smoothly, but slightly less frequently to avoid jitter
        if (currentFrame % 3 === 0) {
            driverMap.panTo(newPos);
        }
    }, intervalMs);
}

const completeRideBtn = document.getElementById('completeRideBtn');
if (completeRideBtn) {
    completeRideBtn.addEventListener('click', async function() {
        if (!activeRideId) return;
        
        this.disabled = true;
        this.textContent = '⏳ Processing...';

        try {
            const response = await authFetch(`/rides/${activeRideId}/complete`, { method: 'PUT' });
            
            let data;
            const text = await response.text();
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error("Non-JSON response from server:", text);
                alert("Server error: " + text.substring(0, 100));
                this.disabled = false;
                this.textContent = '🏁 Complete Ride & Collect Payment';
                return;
            }

            if (response.ok) {
                alert('✅ Ride Completed! Fare has been added to your wallet.');
                document.getElementById('activeRideSection').style.display = 'none';
                const incReqCard = document.getElementById('incomingRequestsCard');
                if (incReqCard) incReqCard.style.display = 'block';
                
                this.style.display = 'none';
                
                // Refresh data
                await fetchAvailableRides();
                await fetchMyTrips();
                
                // Switch to Earnings tab to see new wallet balance
                document.querySelector('.nav-item[data-view="earnings"]').click();
            } else {
                alert(data.error || 'Failed to complete ride');
            }
        } catch (err) {
            console.error('Network catch block:', err);
            alert(`Network error: ${err.message}`);
        }
        
        this.disabled = false;
        this.textContent = '🏁 Complete Ride & Collect Payment';
    });
}

// Initialize map if ready
window.addEventListener('load', initDriverMap);

// ============================================
// ONLINE / OFFLINE TOGGLE
// ============================================
const onlineToggle = document.getElementById('onlineToggle');
const statusLabel = document.getElementById('statusLabel');

onlineToggle.addEventListener('change', function () {
    if (this.checked) {
        statusLabel.className = 'status-badge online';
        statusLabel.innerHTML = '<span class="status-dot"></span> Online';
        fetchAvailableRides().then(() => showIncomingRequests());
    } else {
        statusLabel.className = 'status-badge offline';
        statusLabel.innerHTML = '<span class="status-dot"></span> Offline';
        document.getElementById('incomingRequests').innerHTML =
            '<p style="color:var(--text-muted); text-align:center;">Go online to receive ride requests</p>';
    }
});

// ============================================
// FETCH REAL DATA FROM DATABASE
// ============================================

let availableRides = [];
let myTrips = [];

// Fetch available rides (status = 'Requested') from the API
async function fetchAvailableRides() {
    try {
        const response = await authFetch('/rides/available');
        if (response && response.ok) {
            availableRides = await response.json();
        } else {
            availableRides = [];
        }
    } catch (error) {
        console.error('Error fetching available rides:', error);
        availableRides = [];
    }
    renderAvailableRides();
}

// Fetch driver's own trips from the API
async function fetchMyTrips() {
    try {
        const response = await authFetch('/rides/my-trips');
        if (response && response.ok) {
            myTrips = await response.json();
        } else {
            myTrips = [];
        }
    } catch (error) {
        console.error('Error fetching trips:', error);
        myTrips = [];
    }
    renderTrips();
    updateDashboardStats();
}

// ---- Render Incoming Requests (Dashboard — top 2) ----
function showIncomingRequests() {
    const container = document.getElementById('incomingRequests');
    if (availableRides.length === 0) {
        container.innerHTML = '<p style="color:var(--text-muted); text-align:center;">No ride requests available right now.</p>';
        return;
    }
    container.innerHTML = availableRides.slice(0, 2).map(ride => `
        <div class="ride-card" id="ride-incoming-${ride.RideID}" style="margin-bottom:12px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <strong style="color:var(--text-primary);">${ride.RiderName}</strong>
                <span style="font-size:20px; font-weight:800; color:var(--accent);">Rs. ${ride.Fare}</span>
            </div>
            <div class="ride-route">
                <span class="dot pickup"></span>
                <span>${ride.PickupAddress}</span>
            </div>
            <div class="ride-route">
                <span class="dot dropoff"></span>
                <span>${ride.DropoffAddress}</span>
            </div>
            <div class="ride-actions">
                <button class="btn btn-success btn-sm" onclick="acceptRide(${ride.RideID})">✅ Accept</button>
                <button class="btn btn-danger btn-sm" onclick="declineRide(${ride.RideID})">❌ Decline</button>
            </div>
        </div>
    `).join('');
}

// ---- Render Available Rides (Full List) ----
function renderAvailableRides() {
    const container = document.getElementById('availableRidesList');
    if (availableRides.length === 0) {
        container.innerHTML = '<p style="color:var(--text-muted); text-align:center; padding:20px;">No rides available right now.</p>';
    } else {
        container.innerHTML = '';
        availableRides.forEach(ride => {
            container.innerHTML += `
                <div class="ride-card tilt-card" id="ride-${ride.RideID}">
                    <div class="ride-route">
                        <div class="dot pickup"></div><span>${ride.PickupAddress}</span>
                    </div>
                    <div class="ride-route">
                        <div class="dot dropoff"></div><span>${ride.DropoffAddress}</span>
                    </div>
                    <div class="ride-meta">
                        <span>Fare: Rs. ${ride.Fare}</span>
                        <span>Rider ID: ${ride.RiderID}</span>
                    </div>
                    <div class="ride-actions">
                        <button class="btn btn-success btn-sm" onclick="acceptRide(${ride.RideID})">✔️ Accept</button>
                        <button class="btn btn-danger btn-sm" onclick="declineRide(${ride.RideID})">❌ Decline</button>
                    </div>
                </div>
            `;
        });
        if (window.initTilt) window.initTilt();
    }
}

// ---- Accept Ride — Real API Call ----
async function acceptRide(id) {
    const card = document.getElementById(`ride-${id}`) || document.getElementById(`ride-incoming-${id}`);
    const acceptedRide = availableRides.find(r => r.RideID === id);

    try {
        const response = await authFetch(`/rides/${id}/accept`, {
            method: 'PUT'
        });

        const data = await response.json();

        if (response.ok) {
            if (card) {
                card.style.borderColor = 'var(--success)';
                card.innerHTML = '<p style="text-align:center; color:var(--success); font-weight:600; padding:20px;">✅ Ride Accepted! Starting navigation...</p>';
            }
            
            // Trigger Animation if we have the addresses
            if (acceptedRide) {
                setTimeout(() => {
                    startRideAnimation(acceptedRide.PickupAddress, acceptedRide.DropoffAddress, id, acceptedRide.VehicleType);
                }, 1000);
            }

            // Refresh data
            await fetchAvailableRides();
            await fetchMyTrips();
            showIncomingRequests();
        } else {
            alert(data.error || 'Failed to accept ride.');
        }
    } catch (error) {
        console.error('Accept ride error:', error);
        alert('Network error. Please try again.');
    }
}

// ---- Decline Ride — Real API Call ----
async function declineRide(id) {
    try {
        const response = await authFetch(`/rides/${id}/decline`, {
            method: 'PUT'
        });

        const data = await response.json();

        if (response.ok) {
            // Remove from local arrays and re-render so it instantly disappears
            availableRides = availableRides.filter(r => r.RideID !== id);
            renderAvailableRides();
            showIncomingRequests();
        } else {
            alert(data.error || 'Failed to decline ride.');
        }
    } catch (error) {
        console.error('Decline ride error:', error);
        alert('Network error. Please try again.');
    }
}

// ---- Render Trip History ----
function renderTrips() {
    const tbody = document.getElementById('tripHistoryTable');
    if (myTrips.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:24px;">No trips yet. Accept a ride to get started!</td></tr>';
        return;
    }
    tbody.innerHTML = myTrips.map(trip => {
        let badgeClass = 'badge-success';
        if (trip.RideStatus === 'Cancelled') badgeClass = 'badge-error';
        if (trip.RideStatus === 'Accepted' || trip.RideStatus === 'In Progress') badgeClass = 'badge-warning';
        return `
        <tr>
            <td>${trip.RideID}</td>
            <td>${trip.PickupAddress} → ${trip.DropoffAddress}</td>
            <td>Rs. ${trip.Fare}</td>
            <td>${trip.RiderName}</td>
            <td><span class="badge ${badgeClass}">${trip.RideStatus}</span></td>
        </tr>
    `;
    }).join('');
}

// ---- Update Dashboard Stats ----
function updateDashboardStats() {
    const completedTrips = myTrips.filter(t => t.RideStatus === 'Completed').length;
    document.getElementById('tripsCompleted').textContent = myTrips.length;

    const totalEarnings = myTrips.reduce((sum, t) => sum + parseFloat(t.Fare || 0), 0);
    document.getElementById('todayEarnings').textContent = `Rs. ${totalEarnings.toLocaleString()}`;
}

// ---- Render Earnings ----
function renderEarnings() {
    const tbody = document.getElementById('earningsTable');
    if (myTrips.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:24px;">No earnings data yet.</td></tr>';
        return;
    }

    // Group trips and show as earnings rows
    const totalFare = myTrips.reduce((sum, t) => sum + parseFloat(t.Fare || 0), 0);
    document.getElementById('weeklyEarnings').textContent = `Rs. ${totalFare.toLocaleString()}`;

    tbody.innerHTML = myTrips.map(t => `
        <tr>
            <td>${t.RideID}</td>
            <td>${t.PickupAddress} → ${t.DropoffAddress}</td>
            <td>Rs. ${t.Fare}</td>
            <td>${t.RiderName}</td>
            <td><span class="badge ${t.RideStatus === 'Completed' ? 'badge-success' : 'badge-warning'}">${t.RideStatus}</span></td>
        </tr>
    `).join('');
}

// ---- Load data on page load ----
fetchAvailableRides();
fetchMyTrips().then(() => renderEarnings());

// ---- Profile ----
document.getElementById('driverName').value = user.FullName || '';

document.getElementById('saveDriverProfile').addEventListener('click', function () {
    const msgBox = document.getElementById('driverProfileMsg');
    console.log('Driver profile saved');
    msgBox.textContent = 'Profile updated successfully!';
    msgBox.className = 'message-box success';
});
