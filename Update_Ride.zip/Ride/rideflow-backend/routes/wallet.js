const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken, requireRole } = require('../middleware/authMiddleware');

// ==========================================
// 1. GET WALLET BALANCE
// GET /api/wallet/balance
// ==========================================
router.get('/balance', verifyToken, async (req, res) => {
    try {
        const [rows] = await db.execute(
            'SELECT WalletBalance FROM users WHERE UserID = ?',
            [req.user.UserID]
        );

        if (rows.length === 0) {
            return res.status(404).json({ error: 'User not found.' });
        }

        res.json({ WalletBalance: rows[0].WalletBalance });
    } catch (error) {
        console.error('Get balance error:', error.message);
        res.status(500).json({ error: 'Failed to fetch wallet balance.' });
    }
});

// ==========================================
// 2. TOP UP WALLET
// POST /api/wallet/topup
// ==========================================
router.post('/topup', verifyToken, requireRole(['Rider']), async (req, res) => {
    const { Amount } = req.body;
    const UserID = req.user.UserID;

    if (!Amount || Amount < 100) {
        return res.status(400).json({ error: 'Minimum top-up amount is Rs. 100' });
    }

    try {
        // Update the wallet balance in the users table
        await db.execute(
            'UPDATE users SET WalletBalance = WalletBalance + ? WHERE UserID = ?',
            [Amount, UserID]
        );

        // Insert a payment record for the top-up
        await db.execute(
            `INSERT INTO payments (RiderID, Amount, PaymentMethod, PaymentStatus, PromoCodeDiscountApplied)
             VALUES (?, ?, 'Wallet', 'Paid', 0.00)`,
            [UserID, Amount]
        );

        // Get updated balance
        const [rows] = await db.execute(
            'SELECT WalletBalance FROM users WHERE UserID = ?',
            [UserID]
        );

        const newBalance = rows[0].WalletBalance;

        res.json({
            message: `Rs. ${Amount} added to your wallet successfully!`,
            WalletBalance: newBalance
        });
    } catch (error) {
        console.error('Top up error:', error.message);
        res.status(500).json({ error: 'Failed to top up wallet.' });
    }
});

// ==========================================
// 3. GET TRANSACTION HISTORY
// GET /api/wallet/transactions
// ==========================================
router.get('/transactions', verifyToken, async (req, res) => {
    const UserID = req.user.UserID;

    try {
        const [transactions] = await db.execute(`
            SELECT 
                PaymentID,
                RideID,
                Amount,
                PaymentMethod,
                PaymentStatus,
                TransactionDate
            FROM payments
            WHERE RiderID = ?
            ORDER BY TransactionDate DESC
            LIMIT 20
        `, [UserID]);

        res.json(transactions);
    } catch (error) {
        console.error('Get transactions error:', error.message);
        res.status(500).json({ error: 'Failed to fetch transactions.' });
    }
});

module.exports = router;
