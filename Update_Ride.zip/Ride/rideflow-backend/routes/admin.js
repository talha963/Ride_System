const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken, requireRole } = require('../middleware/authMiddleware');

// ==========================================
// 1. Overview Statistics
// GET /api/admin/overview
// ==========================================
router.get('/overview', verifyToken, requireRole(['Admin']), async (req, res) => {
    try {
        // Run overview queries in parallel
        const [
            [users],
            [activeRides],
            [revenue],
            [suspended],
            [recentUsers],
            [recentRides]
        ] = await Promise.all([
            db.execute('SELECT COUNT(*) as count FROM users'),
            db.execute('SELECT COUNT(*) as count FROM rides WHERE RideStatus IN ("Requested", "Accepted", "Driver En Route", "In Progress")'),
            db.execute('SELECT SUM(Amount) as total FROM payments WHERE PaymentStatus = "Paid"'),
            db.execute('SELECT COUNT(*) as count FROM users WHERE AccountStatus IN ("Suspended", "Banned")'),
            db.execute('SELECT UserID, FullName, Role, RegistrationDate FROM users ORDER BY UserID DESC LIMIT 5'),
            db.execute(`
                SELECT 
                    pl.Address AS PickupAddress,
                    dl.Address AS DropoffAddress,
                    r.Fare,
                    r.RideStatus
                FROM rides r
                JOIN locations pl ON r.PickupLocationID = pl.LocationID
                JOIN locations dl ON r.DropoffLocationID = dl.LocationID
                ORDER BY r.RideID DESC LIMIT 5
            `)
        ]);

        res.json({
            totalUsers: users[0].count,
            activeRides: activeRides[0].count,
            totalRevenue: revenue[0].total || 0,
            suspendedCount: suspended[0].count,
            recentUsers: recentUsers,
            recentRides: recentRides
        });

    } catch (error) {
        console.error('Admin overview error:', error);
        res.status(500).json({ error: 'Failed to fetch admin overview' });
    }
});

// ==========================================
// 2. All Users List
// GET /api/admin/users
// ==========================================
router.get('/users', verifyToken, requireRole(['Admin']), async (req, res) => {
    try {
        const [users] = await db.execute(`
            SELECT UserID, FullName, Email, Role, AccountStatus 
            FROM users 
            ORDER BY UserID DESC
        `);
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

// ==========================================
// 3. All Rides List
// GET /api/admin/rides
// ==========================================
router.get('/rides', verifyToken, requireRole(['Admin']), async (req, res) => {
    try {
        const [rides] = await db.execute(`
            SELECT 
                r.RideID,
                u1.FullName AS RiderName,
                u2.FullName AS DriverName,
                pl.Address AS PickupAddress,
                dl.Address AS DropoffAddress,
                r.Fare,
                r.RideStatus
            FROM rides r
            JOIN users u1 ON r.RiderID = u1.UserID
            LEFT JOIN users u2 ON r.DriverID = u2.UserID
            JOIN locations pl ON r.PickupLocationID = pl.LocationID
            JOIN locations dl ON r.DropoffLocationID = dl.LocationID
            ORDER BY r.RideID DESC
        `);
        res.json(rides);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch rides' });
    }
});

// ==========================================
// 4. Update User Status
// PUT /api/admin/users/:id/status
// ==========================================
router.put('/users/:id/status', verifyToken, requireRole(['Admin']), async (req, res) => {
    const { status } = req.body;
    try {
        await db.execute('UPDATE users SET AccountStatus = ? WHERE UserID = ?', [status, req.params.id]);
        res.json({ message: 'User status updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update user status' });
    }
});

module.exports = router;
