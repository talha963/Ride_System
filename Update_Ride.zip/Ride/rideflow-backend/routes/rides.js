const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken, requireRole } = require('../middleware/authMiddleware');

// ==========================================
// 1. RIDER: Book a New Ride
// POST /api/rides
// ==========================================
router.post('/', verifyToken, requireRole(['Rider']), async (req, res) => {
    const { PickupAddress, DropoffAddress, VehicleType, Fare } = req.body;
    const RiderID = req.user.UserID;
    const actualFare = Fare || 250;

    try {
        // Check if Rider has enough wallet balance
        const [users] = await db.execute('SELECT WalletBalance FROM users WHERE UserID = ?', [RiderID]);
        const walletBalance = parseFloat(users[0].WalletBalance || 0);

        if (walletBalance < actualFare) {
            return res.status(400).json({ error: `You do not have enough money in your wallet. Required: Rs. ${actualFare}` });
        }

        // 1. Insert pickup location
        const [pickupResult] = await db.execute(
            'INSERT INTO locations (Address, Latitude, Longitude) VALUES (?, 0, 0)',
            [PickupAddress]
        );
        const PickupLocationID = pickupResult.insertId;

        // 2. Insert dropoff location
        const [dropoffResult] = await db.execute(
            'INSERT INTO locations (Address, Latitude, Longitude) VALUES (?, 0, 0)',
            [DropoffAddress]
        );
        const DropoffLocationID = dropoffResult.insertId;

        // 3. Insert the ride with status 'Requested'
        const [rideResult] = await db.execute(
            `INSERT INTO rides (RiderID, PickupLocationID, DropoffLocationID, RideStatus, Fare)
             VALUES (?, ?, ?, 'Requested', ?)`,
            [RiderID, PickupLocationID, DropoffLocationID, actualFare]
        );

        res.status(201).json({
            message: 'Ride requested successfully!',
            RideID: rideResult.insertId,
            status: 'Requested'
        });
    } catch (error) {
        console.error('Book ride error:', error.message);
        res.status(500).json({ error: 'Failed to book ride.' });
    }
});

// ==========================================
// 2. DRIVER: Get Available (Requested) Rides
// GET /api/rides/available
// ==========================================
router.get('/available', verifyToken, requireRole(['Driver']), async (req, res) => {
    try {
        const [rides] = await db.execute(`
            SELECT 
                r.RideID,
                u.FullName AS RiderName,
                pl.Address AS PickupAddress,
                dl.Address AS DropoffAddress,
                r.Fare,
                r.RideStatus
            FROM rides r
            JOIN users u ON r.RiderID = u.UserID
            JOIN locations pl ON r.PickupLocationID = pl.LocationID
            JOIN locations dl ON r.DropoffLocationID = dl.LocationID
            WHERE r.RideStatus = 'Requested'
            ORDER BY r.RideID DESC
        `);

        res.json(rides);
    } catch (error) {
        console.error('Get available rides error:', error.message);
        res.status(500).json({ error: 'Failed to fetch available rides.' });
    }
});

// ==========================================
// 3. DRIVER: Accept a Ride
// PUT /api/rides/:id/accept
// ==========================================
router.put('/:id/accept', verifyToken, requireRole(['Driver']), async (req, res) => {
    const RideID = req.params.id;
    const DriverID = req.user.UserID;

    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        // Check ride is still available and lock the row
        const [rides] = await connection.execute(
            'SELECT * FROM rides WHERE RideID = ? AND RideStatus = ? FOR UPDATE',
            [RideID, 'Requested']
        );

        if (rides.length === 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'Ride is no longer available.' });
        }

        const ride = rides[0];
        const riderID = ride.RiderID;
        const fare = parseFloat(ride.Fare || 0);

        // Verify rider still has enough balance
        const [users] = await connection.execute('SELECT WalletBalance FROM users WHERE UserID = ? FOR UPDATE', [riderID]);
        const walletBalance = parseFloat(users[0].WalletBalance || 0);

        if (walletBalance < fare) {
            await connection.rollback();
            return res.status(400).json({ error: 'Rider does not have enough balance to complete this ride.' });
        }

        // Find the driver's vehicle (if any)
        const [vehicles] = await connection.execute(
            'SELECT VehicleID FROM vehicles WHERE DriverID = ? LIMIT 1',
            [DriverID]
        );
        const VehicleID = vehicles.length > 0 ? vehicles[0].VehicleID : null;

        // Update ride: assign driver and change status to 'Accepted'
        await connection.execute(
            `UPDATE rides SET DriverID = ?, VehicleID = ?, RideStatus = 'Accepted' WHERE RideID = ?`,
            [DriverID, VehicleID, RideID]
        );

        // Update driver availability
        await connection.execute(
            `UPDATE drivers SET AvailabilityStatus = 'On Trip' WHERE DriverID = ?`,
            [DriverID]
        );

        // NOTE: We no longer deduct money here. This happens in /complete

        await connection.commit();
        res.json({ message: 'Ride accepted successfully!', RideID, status: 'Accepted' });
    } catch (error) {
        await connection.rollback();
        console.error('Accept ride error:', error.message);
        res.status(500).json({ error: 'Failed to accept ride.' });
    } finally {
        connection.release();
    }
});

// ==========================================
// 3.5 DRIVER: Complete a Ride
// PUT /api/rides/:id/complete
// ==========================================
router.put('/:id/complete', verifyToken, requireRole(['Driver']), async (req, res) => {
    const RideID = req.params.id;
    const DriverID = req.user.UserID;

    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        // Check ride is accepted and lock the row
        const [rides] = await connection.execute(
            'SELECT * FROM rides WHERE RideID = ? AND RideStatus = ? FOR UPDATE',
            [RideID, 'Accepted']
        );

        if (rides.length === 0) {
            await connection.rollback();
            connection.release();
            return res.status(400).json({ error: 'Ride is not in Accepted state.' });
        }

        const ride = rides[0];
        const riderID = ride.RiderID;
        const fare = parseFloat(ride.Fare || 0);

        // Update ride status to Completed
        await connection.execute(
            `UPDATE rides SET RideStatus = 'Completed' WHERE RideID = ?`,
            [RideID]
        );

        // Update driver availability back to 'Online'
        await connection.execute(
            `UPDATE drivers SET AvailabilityStatus = 'Online' WHERE DriverID = ?`,
            [DriverID]
        );

        // Deduct fare from Rider
        await connection.execute(
            'UPDATE users SET WalletBalance = WalletBalance - ? WHERE UserID = ?',
            [fare, riderID]
        );

        // Add fare to Driver
        await connection.execute(
            'UPDATE users SET WalletBalance = WalletBalance + ? WHERE UserID = ?',
            [fare, DriverID]
        );

        // Record the payment
        await connection.execute(
            `INSERT INTO payments (RideID, RiderID, Amount, PaymentMethod, PaymentStatus)
             VALUES (?, ?, ?, 'Wallet', 'Paid')`,
            [RideID, riderID, fare]
        );

        await connection.commit();
        res.json({ message: 'Ride completed and payment processed!', RideID, status: 'Completed' });
        
    } catch (error) {
        console.error('Complete ride error:', error);
        
        if (connection) {
            try {
                await connection.rollback();
            } catch (rollbackErr) {
                console.error('Rollback error:', rollbackErr);
            }
        }
        
        // Send a proper JSON error response
        if (!res.headersSent) {
            res.status(500).json({ error: 'Failed to complete ride: ' + error.message });
        }
    } finally {
        if (connection) {
            connection.release();
        }
    }
});

// ==========================================
// 4. DRIVER: Decline a Ride (no DB change, just acknowledge)
// PUT /api/rides/:id/decline
// ==========================================
router.put('/:id/decline', verifyToken, requireRole(['Driver']), async (req, res) => {
    const RideID = req.params.id;

    try {
        const [result] = await db.execute(
            `UPDATE rides SET RideStatus = 'Cancelled' WHERE RideID = ? AND RideStatus = 'Requested'`,
            [RideID]
        );

        if (result.affectedRows === 0) {
            return res.status(400).json({ error: 'Ride cannot be declined or is no longer available.' });
        }

        res.json({ message: 'Ride declined.', RideID });
    } catch (error) {
        console.error('Decline ride error:', error.message);
        res.status(500).json({ error: 'Failed to decline ride.' });
    }
});

// ==========================================
// 5. RIDER: Get My Rides
// GET /api/rides/my-rides
// ==========================================
router.get('/my-rides', verifyToken, requireRole(['Rider']), async (req, res) => {
    const RiderID = req.user.UserID;

    try {
        const [rides] = await db.execute(`
            SELECT 
                r.RideID,
                r.DriverID,
                pl.Address AS PickupAddress,
                dl.Address AS DropoffAddress,
                r.Fare,
                r.RideStatus,
                u.FullName AS DriverName,
                v.Make AS VehicleMake,
                v.Model AS VehicleModel,
                v.LicensePlate AS VehiclePlate,
                (SELECT COUNT(*) FROM ratings rt WHERE rt.RideID = r.RideID AND rt.RatedBy = 'Rider') AS HasRated
            FROM rides r
            JOIN locations pl ON r.PickupLocationID = pl.LocationID
            JOIN locations dl ON r.DropoffLocationID = dl.LocationID
            LEFT JOIN users u ON r.DriverID = u.UserID
            LEFT JOIN vehicles v ON r.VehicleID = v.VehicleID
            WHERE r.RiderID = ?
            ORDER BY r.RideID DESC
        `, [RiderID]);

        res.json(rides);
    } catch (error) {
        console.error('Get my rides error:', error.message);
        res.status(500).json({ error: 'Failed to fetch rides.' });
    }
});

// ==========================================
// 5.5 RIDER: Rate a Driver
// POST /api/rides/:id/rate
// ==========================================
router.post('/:id/rate', verifyToken, requireRole(['Rider']), async (req, res) => {
    const RideID = req.params.id;
    const { Score } = req.body;
    const RiderID = req.user.UserID;

    if (!Score || Score < 1 || Score > 5) {
        return res.status(400).json({ error: 'Invalid score. Must be between 1 and 5.' });
    }

    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        // Check if ride is completed and belongs to rider
        const [rides] = await connection.execute(
            'SELECT DriverID, RideStatus FROM rides WHERE RideID = ? AND RiderID = ?',
            [RideID, RiderID]
        );

        if (rides.length === 0 || rides[0].RideStatus !== 'Completed') {
            await connection.rollback();
            return res.status(400).json({ error: 'Ride not found or not completed.' });
        }

        const DriverID = rides[0].DriverID;

        // Insert Rating
        await connection.execute(
            `INSERT INTO ratings (RideID, RatedUserID, RatedBy, Score) VALUES (?, ?, 'Rider', ?)`,
            [RideID, DriverID, Score]
        );

        // Update Driver Average Rating
        const [avg] = await connection.execute(
            `SELECT AVG(Score) as avgScore FROM ratings WHERE RatedUserID = ? AND RatedBy = 'Rider'`,
            [DriverID]
        );

        const newAvg = avg[0].avgScore || 0;

        await connection.execute(
            `UPDATE drivers SET AverageRating = ? WHERE DriverID = ?`,
            [newAvg, DriverID]
        );

        await connection.commit();
        res.json({ message: 'Rating submitted successfully!' });
    } catch (error) {
        if (connection) await connection.rollback();
        console.error('Rate driver error:', error.message);
        res.status(500).json({ error: 'Failed to submit rating.' });
    } finally {
        if (connection) connection.release();
    }
});

// ==========================================
// 6. DRIVER: Get My Trips (Accepted/Completed)
// GET /api/rides/my-trips
// ==========================================
router.get('/my-trips', verifyToken, requireRole(['Driver']), async (req, res) => {
    const DriverID = req.user.UserID;

    try {
        const [trips] = await db.execute(`
            SELECT 
                r.RideID,
                u.FullName AS RiderName,
                pl.Address AS PickupAddress,
                dl.Address AS DropoffAddress,
                r.Fare,
                r.RideStatus
            FROM rides r
            JOIN users u ON r.RiderID = u.UserID
            JOIN locations pl ON r.PickupLocationID = pl.LocationID
            JOIN locations dl ON r.DropoffLocationID = dl.LocationID
            WHERE r.DriverID = ?
            ORDER BY r.RideID DESC
        `, [DriverID]);

        res.json(trips);
    } catch (error) {
        console.error('Get my trips error:', error.message);
        res.status(500).json({ error: 'Failed to fetch trips.' });
    }
});

module.exports = router;
