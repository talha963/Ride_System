const express = require('express');
const cors = require('cors');
require('dotenv').config();
const db = require('./db'); // Imports the connection pool we just made

const app = express();

// Middleware
app.use(cors());
app.use(express.json()); // Allows us to parse incoming JSON data
// Import the routes
const authRoutes = require('./routes/auth');
const rideRoutes = require('./routes/rides');
const walletRoutes = require('./routes/wallet');
const adminRoutes = require('./routes/admin');

// Tell the app to use the routes. 
// Now, the register link is: http://localhost:5000/api/auth/register
app.use('/api/auth', authRoutes);
app.use('/api/rides', rideRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/admin', adminRoutes);

// A simple test route to verify the server is running
app.get('/api/status', (req, res) => {
    res.json({ message: 'RideFlow API is running smoothly.' });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});