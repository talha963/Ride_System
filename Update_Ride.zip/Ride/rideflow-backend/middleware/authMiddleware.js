const jwt = require('jsonwebtoken');

// Middleware to verify the JWT token
const verifyToken = (req, res, next) => {
    // Get the token from the request header
    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).json({ error: 'Access Denied. No token provided.' });
    }

    try {
        // Remove "Bearer " if it exists in the string
        const actualToken = token.startsWith('Bearer ') ? token.slice(7, token.length) : token;

        // Verify the token using your secret key
        const verified = jwt.verify(actualToken, process.env.JWT_SECRET);

        // Attach the verified user data (UserID and Role) to the request
        req.user = verified;

        // Move on to the actual API route
        next();
    } catch (error) {
        res.status(400).json({ error: 'Invalid Token.' });
    }
};

// Middleware to restrict access based on User Role
const requireRole = (roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.Role)) {
            return res.status(403).json({ error: 'Access Denied. You do not have permission to perform this action.' });
        }
        next();
    };
};

module.exports = { verifyToken, requireRole };