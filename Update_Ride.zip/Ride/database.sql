CREATE DATABASE IF NOT EXISTS RideFlowDB;
USE RideFlowDB;

# 1. Create USERS Table
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(150) NOT NULL UNIQUE,
    PhoneNumber VARCHAR(20) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    Role ENUM('Admin', 'Rider', 'Driver') NOT NULL,
    AccountStatus ENUM('Active', 'Suspended', 'Banned') DEFAULT 'Active',
    RegistrationDate DATETIME DEFAULT CURRENT_TIMESTAMP
);

# 2. Create LOCATIONS Table (Needed before Rides)
CREATE TABLE Locations (
    LocationID INT AUTO_INCREMENT PRIMARY KEY,
    Latitude DECIMAL(10, 8) NOT NULL,
    Longitude DECIMAL(11, 8) NOT NULL,
    Address VARCHAR(255) NOT NULL
);

# 3. Create PROMO_CODES Table (Needed before Payments)
CREATE TABLE PromoCodes (
    PromoCodeID INT AUTO_INCREMENT PRIMARY KEY,
    Code VARCHAR(20) NOT NULL UNIQUE,
    DiscountValue DECIMAL(5, 2) NOT NULL, # Can be flat rate or percentage based on app logic
    ExpiryDate DATETIME NOT NULL
);

# 4. Create DRIVERS Table
CREATE TABLE Drivers (
    DriverID INT PRIMARY KEY,
    LicenseNumber VARCHAR(50) NOT NULL UNIQUE,
    CNIC VARCHAR(20) NOT NULL UNIQUE,
    ProfilePhoto VARCHAR(255),
    VerificationStatus ENUM('Pending', 'Verified', 'Rejected') DEFAULT 'Pending',
    AvailabilityStatus ENUM('Online', 'Offline', 'On Trip') DEFAULT 'Offline',
    TotalTripsCompleted INT DEFAULT 0,
    AverageRating DECIMAL(3, 2) DEFAULT 5.00 CHECK (AverageRating >= 1.0 AND AverageRating <= 5.0),
    FOREIGN KEY (DriverID) REFERENCES Users(UserID) ON DELETE CASCADE
);

# 5. Create VEHICLES Table
CREATE TABLE Vehicles (
    VehicleID INT AUTO_INCREMENT PRIMARY KEY,
    DriverID INT NOT NULL,
    Make VARCHAR(50) NOT NULL,
    Model VARCHAR(50) NOT NULL,
    Year INT NOT NULL CHECK (Year >= 2000),
    Color VARCHAR(30) NOT NULL,
    LicensePlate VARCHAR(20) NOT NULL UNIQUE,
    VehicleType ENUM('Economy', 'Premium', 'Bike') NOT NULL,
    VerificationStatus ENUM('Pending', 'Verified', 'Rejected') DEFAULT 'Pending',
    FOREIGN KEY (DriverID) REFERENCES Drivers(DriverID) ON DELETE CASCADE
);

# 6. Create RIDES Table
CREATE TABLE Rides (
    RideID INT AUTO_INCREMENT PRIMARY KEY,
    RiderID INT NOT NULL,
    DriverID INT, # Nullable initially until a driver accepts
    VehicleID INT, # Nullable until accepted
    PickupLocationID INT NOT NULL,
    DropoffLocationID INT NOT NULL,
    RideStatus ENUM('Requested', 'Accepted', 'Driver En Route', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Requested',
    Fare DECIMAL(10, 2),
    FOREIGN KEY (RiderID) REFERENCES Users(UserID),
    FOREIGN KEY (DriverID) REFERENCES Drivers(DriverID),
    FOREIGN KEY (VehicleID) REFERENCES Vehicles(VehicleID),
    FOREIGN KEY (PickupLocationID) REFERENCES Locations(LocationID),
    FOREIGN KEY (DropoffLocationID) REFERENCES Locations(LocationID)
);

# 7. Create PAYMENTS Table
CREATE TABLE Payments (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    RideID INT NOT NULL UNIQUE, -- 1:1 Relationship
    RiderID INT NOT NULL,
    PromoCodeID INT, -- Nullable
    Amount DECIMAL(10, 2) NOT NULL,
    PaymentMethod ENUM('Cash', 'Wallet', 'Card') NOT NULL,
    PaymentStatus ENUM('Pending', 'Paid', 'Failed', 'Refunded') DEFAULT 'Pending',
    TransactionDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    PromoCodeDiscountApplied DECIMAL(10, 2) DEFAULT 0.00,
    FOREIGN KEY (RideID) REFERENCES Rides(RideID),
    FOREIGN KEY (RiderID) REFERENCES Users(UserID),
    FOREIGN KEY (PromoCodeID) REFERENCES PromoCodes(PromoCodeID)
);

# 8. Create RATINGS Table
CREATE TABLE Ratings (
    RatingID INT AUTO_INCREMENT PRIMARY KEY,
    RideID INT NOT NULL,
    RatedUserID INT NOT NULL,
    RatedBy ENUM('Rider', 'Driver') NOT NULL,
    Score INT NOT NULL CHECK (Score >= 1 AND Score <= 5),
    Comment TEXT,
    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (RideID) REFERENCES Rides(RideID),
    FOREIGN KEY (RatedUserID) REFERENCES Users(UserID)
);

# 9. Create COMPLAINTS Table
CREATE TABLE Complaints (
    ComplaintID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    RideID INT NOT NULL,
    Description TEXT NOT NULL,
    ResolutionStatus ENUM('Open', 'Under Review', 'Resolved') DEFAULT 'Open',
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (RideID) REFERENCES Rides(RideID)
);
-- ============================================================================================================================

ALTER TABLE Users ADD COLUMN WalletBalance DECIMAL(10,2) DEFAULT 0.00;

CREATE ROLE IF NOT EXISTS 'SuperAdmin', 'RiderRole', 'DriverRole';

GRANT ALL PRIVILEGES ON RideFlowDB.* TO 'SuperAdmin';

GRANT SELECT, INSERT, UPDATE ON RideFlowDB.Rides TO 'RiderRole';
GRANT SELECT, INSERT ON RideFlowDB.Payments TO 'RiderRole';
GRANT SELECT, INSERT ON RideFlowDB.Ratings TO 'RiderRole';
GRANT SELECT ON RideFlowDB.PromoCodes TO 'RiderRole';

GRANT SELECT, UPDATE ON RideFlowDB.Rides TO 'DriverRole';
GRANT SELECT, UPDATE ON RideFlowDB.Drivers TO 'DriverRole';
GRANT SELECT, INSERT, UPDATE ON RideFlowDB.Vehicles TO 'DriverRole';
GRANT SELECT, INSERT ON RideFlowDB.Ratings TO 'DriverRole';

DELIMITER //

CREATE TRIGGER trg_EnforceVerifiedVehicle
BEFORE UPDATE ON Rides
FOR EACH ROW
BEGIN
    DECLARE v_VehicleStatus VARCHAR(20);
    
    IF NEW.VehicleID IS NOT NULL THEN
        SELECT VerificationStatus INTO v_VehicleStatus 
        FROM Vehicles WHERE VehicleID = NEW.VehicleID;
        
        IF v_VehicleStatus != 'Verified' THEN
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Error: Only verified vehicles can be used for active rides.';
        END IF;
    END IF;
END //

CREATE TRIGGER trg_ProcessRatings
AFTER INSERT ON Ratings
FOR EACH ROW
BEGIN
    DECLARE v_NewAvg DECIMAL(3,2);
    
    IF NEW.RatedBy = 'Rider' THEN
        SELECT AVG(Score) INTO v_NewAvg FROM Ratings WHERE RatedUserID = NEW.RatedUserID;
        UPDATE Drivers SET AverageRating = v_NewAvg WHERE DriverID = NEW.RatedUserID;
        
        IF v_NewAvg < 3.50 THEN
            UPDATE Users SET AccountStatus = 'Suspended' WHERE UserID = NEW.RatedUserID;
        END IF;
        
    ELSEIF NEW.RatedBy = 'Driver' THEN
        SELECT AVG(Score) INTO v_NewAvg FROM Ratings WHERE RatedUserID = NEW.RatedUserID;
        
        IF v_NewAvg < 3.00 THEN
            UPDATE Users SET AccountStatus = 'Suspended' WHERE UserID = NEW.RatedUserID;
        END IF;
    END IF;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE sp_CalculateFare(
    IN p_RideID INT,
    IN p_BaseRate DECIMAL(10,2),
    IN p_DistanceKM DECIMAL(10,2),
    IN p_PerKMRate DECIMAL(10,2),
    IN p_DurationMin INT,
    IN p_PerMinRate DECIMAL(10,2),
    IN p_IsPeakHour BOOLEAN,
    IN p_PromoCode VARCHAR(20)
)
BEGIN
    DECLARE v_Fare DECIMAL(10,2);
    DECLARE v_Surge DECIMAL(3,2) DEFAULT 1.00;
    DECLARE v_Discount DECIMAL(10,2) DEFAULT 0.00;
    
    IF p_IsPeakHour THEN SET v_Surge = 1.50; END IF;
    
    SET v_Fare = (p_BaseRate + (p_DistanceKM * p_PerKMRate) + (p_DurationMin * p_PerMinRate)) * v_Surge;
    
    IF p_PromoCode IS NOT NULL THEN
        SELECT DiscountValue INTO v_Discount FROM PromoCodes 
        WHERE Code = p_PromoCode AND ExpiryDate > NOW() LIMIT 1;
        SET v_Fare = v_Fare - v_Discount;
        IF v_Fare < 0 THEN SET v_Fare = 0; END IF;
    END IF;
    
    UPDATE Rides SET Fare = v_Fare WHERE RideID = p_RideID;
END //

CREATE PROCEDURE sp_ProcessPayment(
    IN p_RideID INT,
    IN p_PaymentMethod ENUM('Cash', 'Wallet', 'Card')
)
BEGIN
    DECLARE v_Fare DECIMAL(10,2);
    DECLARE v_DriverID INT;
    DECLARE v_RiderID INT;
    DECLARE v_Commission DECIMAL(10,2);
    DECLARE v_DriverEarnings DECIMAL(10,2);
    
    SELECT Fare, DriverID, RiderID INTO v_Fare, v_DriverID, v_RiderID 
    FROM Rides WHERE RideID = p_RideID;
    
    SET v_Commission = v_Fare * 0.20;
    SET v_DriverEarnings = v_Fare - v_Commission;
    
    UPDATE Users SET WalletBalance = WalletBalance + v_DriverEarnings WHERE UserID = v_DriverID;
    
    IF p_PaymentMethod = 'Wallet' THEN
        UPDATE Users SET WalletBalance = WalletBalance - v_Fare WHERE UserID = v_RiderID;
    END IF;
    
    INSERT INTO Payments (RideID, RiderID, Amount, PaymentMethod, PaymentStatus)
    VALUES (p_RideID, v_RiderID, v_Fare, p_PaymentMethod, 'Paid');
    
    UPDATE Rides SET RideStatus = 'Completed' WHERE RideID = p_RideID;
END //

DELIMITER ;

CREATE VIEW vw_Leaderboard AS
SELECT 
    d.DriverID,
    u.FullName, 
    d.AverageRating, 
    d.TotalTripsCompleted
FROM Drivers d
JOIN Users u ON d.DriverID = u.UserID
WHERE d.VerificationStatus = 'Verified' AND u.AccountStatus = 'Active'
ORDER BY d.AverageRating DESC, d.TotalTripsCompleted DESC;

CREATE VIEW vw_FinancialReport AS
SELECT 
    DATE(TransactionDate) as ReportDate,
    PaymentMethod,
    COUNT(PaymentID) as TotalTransactions,
    SUM(Amount) as TotalGrossRevenue,
    SUM(Amount * 0.20) as PlatformCommission
FROM Payments
WHERE PaymentStatus = 'Paid'
GROUP BY DATE(TransactionDate), PaymentMethod;

CREATE VIEW vw_ActiveRides AS
SELECT 
    r.RideID,
    r.RideStatus,
    u_rider.FullName AS RiderName,
    u_driver.FullName AS DriverName,
    v.LicensePlate
FROM Rides r
JOIN Users u_rider ON r.RiderID = u_rider.UserID
LEFT JOIN Drivers d ON r.DriverID = d.DriverID
LEFT JOIN Users u_driver ON d.DriverID = u_driver.UserID
LEFT JOIN Vehicles v ON r.VehicleID = v.VehicleID
WHERE r.RideStatus NOT IN ('Completed', 'Cancelled');

INSERT INTO Locations (Latitude, Longitude, Address) 
VALUES 
(33.6593, 73.0151, 'FAST-NUCES, Islamabad'),
(33.7294, 73.0931, 'The Centaurus Mall'),
(33.6844, 73.0479, 'F-9 Park, Islamabad');
select* from rides;