const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');

// ==========================================
// 1. REGISTER A NEW USER
// ==========================================
router.post('/register', async (req, res) => {
    const { 
        FullName, Email, PhoneNumber, Password, Role,
        CNIC, LicenseNumber, VehicleMake, VehicleModel, 
        VehicleYear, VehicleColor, VehiclePlate, VehicleType
    } = req.body;

    // We will use a transaction so both driver and vehicle inserts succeed or fail together
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        // Hash the password for security
        const salt = await bcrypt.genSalt(10);
        const PasswordHash = await bcrypt.hash(Password, salt);

        // Insert into the users table
        const [result] = await connection.execute(
            'INSERT INTO Users (FullName, Email, PhoneNumber, PasswordHash, Role) VALUES (?, ?, ?, ?, ?)',
            [FullName, Email, PhoneNumber, PasswordHash, Role]
        );
        const newUserID = result.insertId;

        // If the user is a Driver, also create a row in the drivers and vehicles tables
        if (Role === 'Driver') {
            await connection.execute(
                `INSERT INTO drivers (DriverID, LicenseNumber, CNIC, VerificationStatus, AvailabilityStatus, TotalTripsCompleted, AverageRating) 
                 VALUES (?, ?, ?, 'Verified', 'Offline', 0, 0.00)`,
                [newUserID, LicenseNumber, CNIC]
            );

            await connection.execute(
                `INSERT INTO vehicles (DriverID, Make, Model, Year, Color, LicensePlate, VehicleType, VerificationStatus)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'Verified')`,
                [newUserID, VehicleMake, VehicleModel, VehicleYear, VehicleColor, VehiclePlate, VehicleType]
            );
        }

        await connection.commit();
        res.status(201).json({ message: 'User registered successfully!', UserID: newUserID });
    } catch (error) {
        await connection.rollback();
        // Handle duplicate emails or phone numbers, or constraints like unique CNIC/LicensePlate
        if (error.code === 'ER_DUP_ENTRY') {
            if (error.message.includes('Email')) return res.status(400).json({ error: 'Email already exists.' });
            if (error.message.includes('PhoneNumber')) return res.status(400).json({ error: 'Phone Number already exists.' });
            if (error.message.includes('CNIC')) return res.status(400).json({ error: 'CNIC already registered.' });
            if (error.message.includes('LicenseNumber')) return res.status(400).json({ error: 'License Number already registered.' });
            if (error.message.includes('LicensePlate')) return res.status(400).json({ error: 'Vehicle License Plate already registered.' });
            return res.status(400).json({ error: 'A duplicate entry error occurred.' });
        }
        console.error('Registration Error:', error);
        res.status(500).json({ error: 'Server error during registration.' });
    } finally {
        connection.release();
    }
});

// ==========================================
// 2. LOGIN USER & GENERATE TOKEN
// ==========================================
router.post('/login', async (req, res) => {
    const { Email, Password } = req.body;

    try {
        // Hardcoded Admin check
        if (Email === 'talhakhan@gmail.com' && Password === 'admin2026') {
            const token = jwt.sign({ UserID: 9999, Role: 'Admin' }, process.env.JWT_SECRET, { expiresIn: '24h' });
            return res.json({
                message: 'Admin Login successful',
                token: token,
                user: {
                    UserID: 9999,
                    FullName: 'Talha Khan',
                    Role: 'Admin',
                    WalletBalance: 0
                }
            });
        }

        // Find the user by email
        const [users] = await db.execute('SELECT * FROM Users WHERE Email = ?', [Email]);

        if (users.length === 0) {
            return res.status(400).json({ error: 'Invalid credentials.' });
        }

        const user = users[0];

        // Check if the account is suspended or banned
        if (user.AccountStatus !== 'Active') {
            return res.status(403).json({ error: `Account is ${user.AccountStatus}. Please contact support.` });
        }

        // Compare the provided password with the hashed password in the DB
        const isMatch = await bcrypt.compare(Password, user.PasswordHash);
        if (!isMatch) {
            return res.status(400).json({ error: 'Invalid credentials.' });
        }

        // Generate the JWT Token (The "VIP Pass")
        const payload = {
            UserID: user.UserID,
            Role: user.Role
        };

        // Token expires in 24 hours
        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '24h' });

        res.json({
            message: 'Login successful',
            token: token,
            user: {
                UserID: user.UserID,
                FullName: user.FullName,
                Role: user.Role,
                WalletBalance: user.WalletBalance
            }
        });

    } catch (error) {
        res.status(500).json({ error: 'Server error during login.' });
    }
});

module.exports = router;