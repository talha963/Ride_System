async function test() {
    try {
        const res = await fetch('http://localhost:5000/api/promocodes/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Code: 'FIRST50' })
        });
        const text = await res.text();
        console.log('Status:', res.status);
        console.log('Body:', text);
    } catch (e) {
        console.error('Error:', e);
    }
}
test();
