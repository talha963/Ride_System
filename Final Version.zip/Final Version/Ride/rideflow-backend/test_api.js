async function testApiRegistration() {
    try {
        const response = await fetch('http://localhost:5000/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                FullName: 'API Test Driver',
                Email: 'apitestdriver' + Date.now() + '@example.com',
                PhoneNumber: '0300' + Math.floor(1000000 + Math.random() * 9000000),
                Password: 'password123',
                Role: 'Driver',
                CNIC: '37405-1234567-' + Math.floor(Math.random() * 9),
                LicenseNumber: 'DL-' + Date.now(),
                VehicleMake: 'Honda',
                VehicleModel: 'Civic',
                VehicleYear: 2022,
                VehicleColor: 'Black',
                VehiclePlate: 'XYZ-' + Math.floor(Math.random() * 999),
                VehicleType: 'Premium'
            })
        });

        const data = await response.json();
        console.log("Status:", response.status);
        console.log("Response:", data);
    } catch (err) {
        console.error("Fetch error:", err);
    }
}

testApiRegistration();
