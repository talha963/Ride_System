const mysql = require('mysql2/promise');
require('dotenv').config();

async function testRegistration() {
    const pool = mysql.createPool({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        const [result] = await connection.execute(
            'INSERT INTO Users (FullName, Email, PhoneNumber, PasswordHash, Role) VALUES (?, ?, ?, ?, ?)',
            ['Test Driver 2', 'testdriver2@example.com', '12345678902', 'hashedpassword', 'Driver']
        );
        const newUserID = result.insertId;

        console.log("User inserted with ID:", newUserID);

        await connection.execute(
            `INSERT INTO drivers (DriverID, LicenseNumber, CNIC, VerificationStatus, AvailabilityStatus, TotalTripsCompleted, AverageRating) 
             VALUES (?, ?, ?, 'Verified', 'Offline', 0, 5.00)`,
            [newUserID, 'LIC123456789', 'CNIC1234567899']
        );

        console.log("Driver inserted");

        await connection.execute(
            `INSERT INTO vehicles (DriverID, Make, Model, Year, Color, LicensePlate, VehicleType, VerificationStatus)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'Verified')`,
            [newUserID, 'Toyota', 'Corolla', 2020, 'White', 'ABC-1234', 'Premium']
        );

        console.log("Vehicle inserted");

        await connection.commit();
        console.log("Transaction committed successfully");

    } catch (error) {
        console.error("Error during transaction:", error);
        await connection.rollback();
    } finally {
        connection.release();
        pool.end();
    }
}

testRegistration();
