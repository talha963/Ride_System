const fs = require('fs');

async function checkErrorLogs() {
    // We will start the server on port 5001 to see the logs
    const { exec } = require('child_process');
    
    // We will modify server.js temporarily to run on 5001 just to see the error
    let serverCode = fs.readFileSync('server.js', 'utf8');
    
    const child = exec('node server.js', { env: { ...process.env, PORT: 5001 } });
    
    child.stdout.on('data', (data) => console.log('STDOUT:', data));
    child.stderr.on('data', (data) => console.log('STDERR:', data));

    setTimeout(async () => {
        try {
            const response = await fetch('http://localhost:5001/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    FullName: 'API Test Driver 3',
                    Email: 'apitestdriver3' + Date.now() + '@example.com',
                    PhoneNumber: '0300' + Math.floor(1000000 + Math.random() * 9000000),
                    Password: 'password123',
                    Role: 'Driver',
                    CNIC: '37405-1234567-' + Math.floor(Math.random() * 9),
                    LicenseNumber: 'DL-' + Date.now(),
                    VehicleMake: 'Honda',
                    VehicleModel: 'Civic',
                    VehicleYear: 2022,
                    VehicleColor: 'Black',
                    VehiclePlate: 'XYZ-' + Math.floor(Math.random() * 999),
                    VehicleType: 'Premium'
                })
            });

            console.log("Status:", response.status);
            const data = await response.json();
            console.log("Response:", data);
        } catch (e) {
            console.error("Fetch failed:", e);
        }

        setTimeout(() => {
            child.kill();
            process.exit(0);
        }, 1000);
    }, 2000);
}

checkErrorLogs();
