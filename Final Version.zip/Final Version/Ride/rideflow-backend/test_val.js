

async function test() {
    const response = await fetch('http://localhost:5000/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            FullName: 'Validation Test Driver',
            Email: 'val' + Date.now() + '@example.com',
            PhoneNumber: '0300' + Math.floor(1000000 + Math.random() * 9000000),
            Password: 'password123',
            Role: 'Driver',
            CNIC: '37405-1234567-9',
            LicenseNumber: 'DL-' + Date.now(),
            VehicleMake: 'Honda',
            VehicleModel: 'Civic',
            VehicleYear: null, // THIS IS WHAT THE BROWSER SENDS WHEN EMPTY
            VehicleColor: 'Black',
            VehiclePlate: 'XYZ-123',
            VehicleType: 'Premium'
        })
    });
    
    const data = await response.json();
    console.log("Status:", response.status);
    console.log("Response:", data);
}

test();
