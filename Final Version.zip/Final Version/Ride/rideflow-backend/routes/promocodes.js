const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken, requireRole } = require('../middleware/authMiddleware');

// ==========================================
// Verify a Promo Code
// POST /api/promocodes/verify
// ==========================================
router.post('/verify', verifyToken, requireRole(['Rider']), async (req, res) => {
    const { Code } = req.body;

    if (!Code) {
        return res.status(400).json({ error: 'Promo code is required.' });
    }

    try {
        const [promos] = await db.execute(
            'SELECT PromoCodeID, DiscountValue, ExpiryDate FROM PromoCodes WHERE Code = ? LIMIT 1',
            [Code]
        );

        if (promos.length === 0) {
            return res.status(400).json({ error: 'Invalid promo code.' });
        }

        const promo = promos[0];

        // Check if expired
        if (new Date(promo.ExpiryDate) < new Date()) {
            return res.status(400).json({ error: 'This promo code has expired.' });
        }

        res.json({
            message: 'Promo code applied!',
            PromoCodeID: promo.PromoCodeID,
            DiscountValue: parseFloat(promo.DiscountValue)
        });
    } catch (error) {
        console.error('Verify promo error:', error.message);
        res.status(500).json({ error: 'Failed to verify promo code.' });
    }
});

module.exports = router;
