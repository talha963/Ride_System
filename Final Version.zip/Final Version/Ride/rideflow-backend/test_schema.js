const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkSchema() {
    const pool = mysql.createPool({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });

    const connection = await pool.getConnection();
    try {
        const [rows] = await connection.execute("DESCRIBE vehicles");
        console.log("Vehicles Schema:");
        console.table(rows);
    } catch (error) {
        console.error("Error:", error);
    } finally {
        connection.release();
        pool.end();
    }
}

checkSchema();
