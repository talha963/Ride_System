const fs = require('fs');

async function checkErrorLogs() {
    const { exec } = require('child_process');
    
    const child = exec('node server.js', { env: { ...process.env, PORT: 5002 } });
    
    child.stdout.on('data', (data) => console.log('STDOUT:', data));
    child.stderr.on('data', (data) => console.log('STDERR:', data));

    setTimeout(async () => {
        try {
            const response = await fetch('http://localhost:5002/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    FullName: 'API Test Driver 4',
                    Email: 'apitestdriver4' + Date.now() + '@example.com',
                    PhoneNumber: '0300' + Math.floor(1000000 + Math.random() * 9000000),
                    Password: 'password123',
                    Role: 'Driver',
                    CNIC: '37405-1234567-' + Math.floor(Math.random() * 9),
                    LicenseNumber: 'DL-' + Date.now(),
                    VehicleMake: 'Honda',
                    VehicleModel: 'Civic',
                    VehicleYear: null, // Simulate frontend parsing "" to NaN, which JSON.stringify turns into null
                    VehicleColor: 'Black',
                    VehiclePlate: 'XYZ-' + Math.floor(Math.random() * 999),
                    VehicleType: 'Premium'
                })
            });

            console.log("Status:", response.status);
            const data = await response.json();
            console.log("Response:", data);
        } catch (e) {
            console.error("Fetch failed:", e);
        }

        setTimeout(() => {
            child.kill();
            process.exit(0);
        }, 1000);
    }, 2000);
}

checkErrorLogs();
