const db = require('./db');

async function updateDB() {
    try {
        await db.execute("ALTER TABLE Vehicles MODIFY COLUMN VehicleType ENUM('Economy', 'Premium', 'Bike', 'Courier') NOT NULL");
        console.log("Database schema updated!");
        
        // Also ensure PromoCodes table has some dummy codes since we're using them
        await db.execute("INSERT IGNORE INTO PromoCodes (Code, DiscountValue, ExpiryDate) VALUES ('FIRST50', 50.00, '2026-12-31')");
        await db.execute("INSERT IGNORE INTO PromoCodes (Code, DiscountValue, ExpiryDate) VALUES ('RIDE20', 20.00, '2026-12-31')");
        
        process.exit(0);
    } catch (e) {
        console.error(e);
        process.exit(1);
    }
}

updateDB();
