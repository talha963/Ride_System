// Enhanced 3D Tilt Effect System with Dynamic Glare
document.addEventListener('DOMContentLoaded', () => {
    const tiltElements = document.querySelectorAll('.tilt-3d');

    tiltElements.forEach(el => {
        // Create glare element if it doesn't exist
        if (!el.querySelector('.glare')) {
            const glare = document.createElement('div');
            glare.className = 'glare';
            glare.style.position = 'absolute';
            glare.style.top = '0';
            glare.style.left = '0';
            glare.style.width = '100%';
            glare.style.height = '100%';
            glare.style.pointerEvents = 'none';
            glare.style.background = 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0.2) 0%, transparent 50%)';
            glare.style.opacity = '0';
            glare.style.transition = 'opacity 0.3s ease';
            glare.style.zIndex = '10';
            // ensure the parent element has relative positioning and hidden overflow if needed
            // el.style.position = 'relative'; 
            // el.style.overflow = 'hidden'; // Actually, overflow hidden might clip shadows, so just relative
            el.appendChild(glare);
        }

        el.addEventListener('mousemove', (e) => {
            const rect = el.getBoundingClientRect();
            const x = e.clientX - rect.left; 
            const y = e.clientY - rect.top;  

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            // Calculate rotation (more controllable limit)
            const rotateX = ((y - centerY) / centerY) * -6;
            const rotateY = ((x - centerX) / centerX) * 6;

            // Add smooth transition for the transform so it doesn't snap instantly
            el.style.transition = 'transform 0.1s ease-out, box-shadow 0.1s ease-out';
            el.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
            
            // Glare logic
            const glare = el.querySelector('.glare');
            if (glare) {
                glare.style.opacity = '1';
                glare.style.background = `radial-gradient(circle at ${x}px ${y}px, rgba(255,255,255,0.15) 0%, transparent 60%)`;
            }
        });

        el.addEventListener('mouseleave', () => {
            // Reset smoothly with a longer transition
            el.style.transition = 'transform 0.5s ease-out, box-shadow 0.5s ease-out';
            el.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
            const glare = el.querySelector('.glare');
            if (glare) {
                glare.style.opacity = '0';
            }
        });
    });
});
