// ============================================
// auth.js — Shared Authentication Utilities
// Used by ALL dashboard pages for token management
// ============================================

const API_BASE = 'http://localhost:5000/api';

// Get the JWT token from localStorage
function getToken() {
    return localStorage.getItem('token');
}

// Get the logged-in user object from localStorage
function getUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

// Check if user is currently logged in
function isLoggedIn() {
    return !!getToken();
}

// Logout — clear everything and redirect to login
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'index.html?skip=1';
}

// Fetch wrapper that auto-injects the Authorization header
async function authFetch(url, options = {}) {
    const token = getToken();
    if (!token) {
        logout();
        return;
    }

    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...(options.headers || {})
    };

    const response = await fetch(`${API_BASE}${url}`, {
        ...options,
        headers
    });

    // If token is expired/invalid, force logout
    if (response.status === 401 || response.status === 400) {
        try {
            const clonedResponse = response.clone();
            const data = await clonedResponse.json();
            if (data.error && data.error.includes('Token')) {
                logout();
                return;
            }
        } catch (e) {
            // Ignore JSON parsing errors here
        }
    }

    return response;
}

// Route Guard — call this at the top of every dashboard page
// Redirects to login if not authenticated, or to correct dashboard if wrong role
function guardRoute(requiredRole) {
    if (!isLoggedIn()) {
        window.location.href = 'index.html';
        return false;
    }

    const user = getUser();
    if (!user || user.Role !== requiredRole) {
        // Redirect to their correct dashboard
        redirectToDashboard(user ? user.Role : null);
        return false;
    }

    return true;
}

// Redirect user to their role-based dashboard
function redirectToDashboard(role) {
    switch (role) {
        case 'Rider':
            window.location.href = 'rider-dashboard.html';
            break;
        case 'Driver':
            window.location.href = 'driver-dashboard.html';
            break;
        case 'Admin':
            window.location.href = 'admin-dashboard.html';
            break;
        default:
            window.location.href = 'index.html';
    }
}
